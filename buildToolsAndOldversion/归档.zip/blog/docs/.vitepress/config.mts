import { defineConfig } from 'vitepress';

// https://vitepress.dev/reference/site-config
export default defineConfig({
  base: '/blog/',
  title: `Joney's blog`,
  description: `欢迎来到joney.s.li的博客!, 我是全栈工程师Joney, 擅长React、React Native、Nestjs, 同时研究Python和深度学习。这里分享技术经验和见解,助您成长!`,
  head: [
    // 解析keywords
    [
      'meta',
      {
        name: 'keywords',
        content:
          '全栈工程师,React, React Native,Nestjs,嵌入式系统,Python,深度学习,技术博客',
      },
    ],
    [
      'link',
      {
        rel: 'icon',
        type: 'image/png',
        href: '/blog/favicon.png',
      },
    ],
    // 解析Google分析
    [
      'script',
      {},
      `
      <!-- Google Tag Manager -->
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-5TNXFHDQ');
        <!-- End Google Tag Manager -->
      `,
    ],
  ],
  locales: {
    root: {
      label: '中文',
      lang: 'CN',
    },
    // en: { 后续再做
    //   label: "English",
    //   lang: "en",
    //   // 其余 locale 特定属性...
    // },
  },
  lastUpdated: true, // 最后更新时间
  themeConfig: {
    search: {
      provider: 'local',
    },
    // https://vitepress.dev/reference/default-theme-config
    nav: [
      { text: 'Nest指南', link: 'https://iamjoney.com/' },
      { text: '跨平台', link: 'https://iamjoney.com/cross-platform/' },
      { text: '关于我', link: '/about-me' },
    ],
    socialLinks: [
      { icon: 'github', link: 'https://github.com/BM-laoli' },
      {
        icon: 'facebook',
        link: 'https://www.facebook.com/profile.php?id=100090021285773',
      },
    ],
    sidebar: [
      {
        text: '网络日志-善省',
        collapsed: true,
        items: [
          // {
          //   text: '2024-2月至4月-面试',
          //   link: '/shanxing/2024-02',
          // },
          {
            text: '2024-1月',
            link: '/shanxing/2024-01',
          },
          {
            text: '2023-12月-在海南',
            link: '/shanxing/2023-12',
          },
        ],
      },
    ],
    footer: {
      // message: '',
      copyright: 'Copyright © 2024 Joney.S.lI',
    },
  },
});
