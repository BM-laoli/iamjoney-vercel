---
title: Nest指南 - Joney.s.li个人介绍
---

# 关于我

我是Joney，以下是我的简介：

前Newegg(成都)全栈工程师(React + .NetCore)

2022重庆前端交流会「同舟」受邀嘉宾 - 《React Native 下的多包实践》

如果你：

<div class="info-content">
  <div class="left">
    <p>是程序员同行想和我交流，可以加我微信（Joneysli）</p>
    <div class="img">
      <img src="./public/aboutme.jpg" />
    </div>
  </div>
  <div class="right">
    <p>如果对你有帮助 ，请Joney喝一杯咖啡吧 🍺 </p>
    <div class="img">
      <img src="./public/wx-zf.jpg" />
    </div>
  </div>
</div>

<style>
.top-20 {
  margin-top: 20px;
}

.info-content {
  display: flex;
  justify-content: space-between;
  width: 100%;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.25);
  padding: 12px;
  border-radius:8px;
}

.left {
  width: 40%;
}

.right {
  width: 40%;
}

.img {
  width:40%;
  height:40%;
}
</style>
