---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "Joney Blog"
  tagline: 这里是Joney的网络博客，我在这里发射属于我的电波，期待能够遇到同频段的你们，一起前行。
  keywords: 全栈工程师,React, React Native,Nestjs,嵌入式系统,Python,深度学习,技术博客
  actions:
    - theme: brand
      text: 网络日志
      link: /shanxing/2023-12
    - theme: alt
      text: Github
      link: https://github.com/BM-laoli
  # image:
  #   src: /nestjs.svg
  #   alt: VitePress 


features:
  - icon: 
      src: /nestjs.svg
      width: 64
      height: 64
    title: Nest指南
    details: 这里是Joney的Nest专栏欢迎订阅👏
    link: https://iamjoney.com/

  - icon: 
      # src: /cross-plateform.jpg
      src: /cross.svg
      width: 64
      height: 64
    title: 跨平台
    details: 这里是Joney的跨平台专栏欢迎订阅👏，收录了包括但不限于 React Native, Electron,Flutter, Android, IOS 等知识。
    link: https://iamjoney.com/cross-platform/

  - icon: 
      src: /log.svg
      width: 60
      height: 60
    title: 网络日志
    details: 这里是Joney的网络日志，在数字的海洋中，你会有什么所思所想呢？，我在这里发射属于我的电波，期待能够遇到同频段的你们，一起前行。
    link: /shanxing/2023-12

---

<div class="top-20"></div>

# 关于我

我是Joney，以下是我的简介：

前Newegg(成都)全栈工程师(React + .NetCore)

2022重庆前端交流会「同舟」受邀嘉宾 - 《React Native 下的多包实践》

如果你：

<div class="info-content">
  <div class="left">
    <p>是程序员同行想和我交流，可以加我微信（Joneysli）</p>
    <div class="img">
      <img src="./public/aboutme.jpg" />
    </div>
  </div>
  <div class="right">
    <p>如果对你有帮助 ，请Joney喝一杯咖啡吧 🍺 </p>
    <div class="img">
      <img src="./public/wx-zf.jpg" />
    </div>
  </div>
</div>

<style>

:root {
  --vp-home-hero-name-color: transparent;
  --vp-home-hero-name-background: -webkit-linear-gradient(120deg, #082258 30%, #41d1ff);

  --vp-home-hero-image-background-image: linear-gradient(-45deg, #082258 70%, #41d1ff 50%);
  --vp-home-hero-image-filter: blur(44px);
}

@media (min-width: 640px) {
  :root {
    --vp-home-hero-image-filter: blur(56px);
  }
}

@media (min-width: 960px) {
  :root {
    --vp-home-hero-image-filter: blur(68px);
  }
}

.top-20 {
  margin-top: 20px;
}

.info-content {
  display: flex;
  justify-content: space-between;
  width: 100%;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.25);
  padding: 12px;
  border-radius:8px;
}

.left {
  width: 40%;
}

.right {
  width: 40%;
}

.img {
  width:40%;
  height:40%;
}

</style>
