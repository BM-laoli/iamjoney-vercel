import { defineConfig } from 'vitepress';

// https://vitepress.dev/reference/site-config
export default defineConfig({
  base: '/cross-platform/',
  title: `Joney's 跨平台专栏`,
  description: `Joney在这个专栏中分享了跨平台解决方案,涵盖了React Native、Flutter,鸿蒙 以及Android和iOS等技术。欢迎订阅并提出宝贵意见。`,
  // srcDir: './src',
  head: [
    // 解析keywords
    [
      'meta',
      {
        name: 'keywords',
        content:
          '跨平台技术、React Native、Flutter、Android、iOS、鸿蒙、技术探索',
      },
    ],
    [
      'link',
      {
        rel: 'icon',
        type: 'image/png',
        href: '/cross-platform/favicon.png',
      },
    ],
    // 解析Google分析
    [
      'script',
      {},
      `
      <!-- Google Tag Manager -->
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-5TNXFHDQ');
        <!-- End Google Tag Manager -->
      `,
    ],
  ],
  locales: {
    root: {
      label: '中文',
      lang: 'CN',
    },
    // en: { 后续再做
    //   label: "English",
    //   lang: "en",
    //   // 其余 locale 特定属性...
    // },
  },
  lastUpdated: true, // 最后更新时间
  themeConfig: {
    search: {
      provider: 'local',
    },
    // https://vitepress.dev/reference/default-theme-config
    nav: [
      { text: 'Nest指南', link: 'https://iamjoney.com/' },
      { text: 'Blog', link: 'https://iamjoney.com/blog/' },
      { text: '关于我', link: '/about-me' },
    ],

    sidebar: [
      {
        text: 'React Native',
        collapsed: true,
        items: [
          {
            text: 'React Native 分包方案-P1',
            link: '/src/rn/p1',
          },
          {
            text: 'React Native 分包方案-P2',
            link: '/src/rn/p2',
          },
          {
            text: '一篇搞定,React Native - IOS Native集成篇',
            link: '/src/rn/p3',
          },
          {
            text: '一篇搞定,React Native - Android Native集成篇',
            link: '/src/rn/p4',
          },
        ],
      },
    ],
    socialLinks: [
      { icon: 'github', link: 'https://github.com/BM-laoli' },
      {
        icon: 'facebook',
        link: 'https://www.facebook.com/profile.php?id=100090021285773',
      },
    ],
    footer: {
      // message: '',
      copyright: 'Copyright © 2024 Joney.S.lI',
    },
  },
});
