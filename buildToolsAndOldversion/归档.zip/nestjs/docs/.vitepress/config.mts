import { defineConfig } from 'vitepress';

// https://vitepress.dev/reference/site-config
export default defineConfig({
  // base: '/nestjs/',
  title: 'Nest指南',
  description: `这可能是你看过最全的 「NestJS」 教程了, 探索最全面的Nest指南,从入门到精通,助您掌握这一流行的Node.js框架。逐步学习核心概念,并从零开始构建强大的应用程序。深入项目实践，构建高效可扩展的应用程序;`,
  head: [
    // 解析keywords
    [
      'meta',
      {
        name: 'keywords',
        content:
          'NestJS, Node.js, TypeScript, 后端开发, Web 开发, 框架教程, 项目实战, 入门指南, 深入学习, 构建应用程序, MVC 架构, API 开发, 依赖注入, 中间件, 数据库集成, 响应式编程, 单元测试, 生产级应用, 最佳实践, 编程指南',
      },
    ],
    [
      'link',
      {
        rel: 'icon',
        type: 'image/png',
        href: './favicon.png',
      },
    ],
    // 解析Google分析
    [
      'script',
      {},
      `
      <!-- Google Tag Manager -->
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-5TNXFHDQ');
        <!-- End Google Tag Manager -->
      `,
    ],
  ],
  locales: {
    root: {
      label: '中文',
      lang: 'CN',
    },
    // en: { 后续再做
    //   label: "English",
    //   lang: "en",
    //   // 其余 locale 特定属性...
    // },
  },
  lastUpdated: true, // 最后更新时间
  themeConfig: {
    // logo: "/public/favicon.png",
    search: {
      provider: 'local',
    },
    // https://vitepress.dev/reference/default-theme-config
    nav: [
      { text: '跨平台', link: 'https://iamjoney.com/cross-platform/' },
      { text: 'Blog', link: 'https://iamjoney.com/blog/' },
      { text: '关于我', link: '/about-me' },
    ],
    socialLinks: [
      { icon: 'github', link: 'https://github.com/BM-laoli' },
      {
        icon: 'facebook',
        link: 'https://www.facebook.com/profile.php?id=100090021285773',
      },
    ],
    sidebar: [
      {
        text: '一期入门',
        collapsed: true,
        items: [
          { text: '从一个小Demo开始', link: '/phase1/p1-1' },
          {
            text: '完善Demo01',
            link: '/phase1/p1-2',
            collapsed: true,
          },
          {
            text: '完善Demo02',
            link: '/phase1/p1-3',
          },
          { text: '总结和收尾', link: '/phase1/p1-4' },
        ],
      },
      {
        text: '二期深入核心概念',
        collapsed: true,
        items: [
          {
            text: '一期的Q&A',
            link: '/phase2/p2-1',
          },
          { text: '深入 Nest 的其它高级操作', link: '/phase2/p2-2' },
          {
            text: '深入 Nest 中的安全问题',
            link: '/phase2/p2-3',
          },
          { text: '集成 websocket 能力', link: '/phase2/p2-4' },
          { text: '关于Nest的 Microservices(微服务)', link: '/phase2/p2-5' },
          {
            text: '关于Nest的工程规范(CLi、项目结构,monorepo)',
            link: '/phase2/p2-6',
          },
          { text: 'Nest 中的OpenAPI', link: '/phase2/p2-7' },
        ],
      },
      {
        text: '三期项目实战',
        collapsed: true,
        items: [
          { text: '基于Nest实现的RBAC系统-1', link: '/phase3/p3-1' },
          { text: '基于Nest实现的RBAC系统-2', link: '/phase3/p3-2' },
          { text: '基于Nest实现的RBAC系统-3', link: '/phase3/p3-3' },
        ],
      },
    ],

    footer: {
      // message: '',
      copyright: 'Copyright © 2024 Joney.S.lI',
    },
  },
});
