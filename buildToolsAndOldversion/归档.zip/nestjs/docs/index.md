---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "Nest指南"
  text: "全网免费的最全面Nest指南"
  tagline: 深入浅出、条理清晰、与Nest保持更新同步
  keywords: 
  actions:
    - theme: brand
      text: 快速开始
      link: /phase1/p1-1
    - theme: alt
      text: Github
      link: https://github.com/BM-laoli/nestjs-http-server-template
  image:
    src: /nestjs.svg
    alt: VitePress


features:
  - icon: 📝
    title: 一期 由简入深
    details: 我们将从一个最简单的一个CURD Service讲起，并带你逐步完善它
    link: /phase1/p1-1

  - icon: 🚀
    title: 二期 深入Nest生态
    details: 我们将会借着CURD Service 深入Nest生态中你将来会用到所有Tools🔧 
    link: /phase2/p2-2

  - icon: 🔥
    title: 三期 项目实战(持续更新中🔥)
    details: 项目实战,我们将基于Nestjs 构建各种各样的应用(RBAC、IAM、聊天室、扫码登录...)
    link: /phase3/p3-1

---


<div class="top-20"></div>

# 关于我

我是Joney，以下是我的简介：

前Newegg(成都)全栈工程师(React + .NetCore)

2022重庆前端交流会「同舟」受邀嘉宾 - 《React Native 下的多包实践》

如果你：

<div class="info-content">
  <div class="left">
    <p>是程序员同行想和我交流，可以加我微信（Joneysli）</p>
    <div class="img">
      <img src="./public/aboutme.jpg" />
    </div>
  </div>
  <div class="right">
    <p>如果对你有帮助 ，请Joney喝一杯咖啡吧 🍺 </p>
    <div class="img">
      <img src="./public/wx-zf.jpg" />
    </div>
  </div>
</div>

<style>
:root {
  --vp-home-hero-name-color: transparent;
  --vp-home-hero-name-background: -webkit-linear-gradient(120deg, #082258 30%, #41d1ff);

  --vp-home-hero-image-background-image: linear-gradient(-45deg, #082258 70%, #41d1ff 50%);
  --vp-home-hero-image-filter: blur(44px);
}

@media (min-width: 640px) {
  :root {
    --vp-home-hero-image-filter: blur(56px);
  }
}

@media (min-width: 960px) {
  :root {
    --vp-home-hero-image-filter: blur(68px);
  }
}

.top-20 {
  margin-top: 20px;
}

.info-content {
  display: flex;
  justify-content: space-between;
  width: 100%;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.25);
  padding: 12px;
  border-radius:8px;
}

.left {
  width: 40%;
}

.right {
  width: 40%;
}

.img {
  width:40%;
  height:40%;
}

</style>
